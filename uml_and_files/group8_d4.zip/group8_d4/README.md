# Link: https://github.com/SEG2105-uottawa/seg2x05-project-team-f19-8

# Team members:

* Samuel Qiu (300027482)
* Lintian Wang (300008136)
* Xinyu Ji (300061354)
* Ingrid Wang (300072664)

admin account:
admin
5T5ptQ

employee account:
sam
Sam@123456

paitent account:
s
Sam@123456