package com.example.walkinclinics;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class UsernameValidatorTest {

        @Test
        public void UsernameValidator_CorrectUsernameSimple_ReturnsTrue() {
            assertTrue(UsernameValidator.isValidUsername("Aba"));
        }
        @Test
        public void UernameValidator_InvalidUsernameNull_ReturnsFalse() {
            assertFalse(UsernameValidator.isValidUsername(""));
        }
        @Test
        public void UsernameValidator_InvalidUsernameLongLength_ReturnsFalse() {
            assertFalse(UsernameValidator.isValidUsername("dhfsviwSfuvuyeu"));
        }
        @Test
        public void UsernameValidator_InvalidUsernameNoUpperCase_ReturnsFalse() {
            assertFalse(UsernameValidator.isValidUsername("sdfgg"));
        }
        @Test
        public void passwordValidator_InvalidUsernameNolowerCase_ReturnsFalse() {
            assertFalse(UsernameValidator.isValidUsername("SQWRIEG"));
        }




}
