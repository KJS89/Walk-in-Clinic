package com.example.walkinclinics;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
public class FirstnameValidatorTest
{
    @Test
    public void FirstnameValidator_CorrectFirstnameSimple_ReturnsTrue() {
        assertTrue(FirstnameValidator.isValidFirstname("Seg"));
    }
    @Test
    public void FirstnameValidator_InvalidFirstnameNull_ReturnsFalse() {
        assertFalse(FirstnameValidator.isValidFirstname(""));
    }
    @Test
    public void FirstnameValidator_InvalidFirstnameLongLength_ReturnsFalse() {
        assertFalse(FirstnameValidator.isValidFirstname("SegprojectSegprojectSegproject"));
    }
    @Test
    public void FirstnameValidator_InvalidFirstnameHasSpecailChar_ReturnsFalse() {
        assertFalse(FirstnameValidator.isValidFirstname("Seg."));
    }
    @Test
    public void FirstnameValidator_InvalidFirstnameNolowerCase_ReturnsFalse() {
        assertFalse(FirstnameValidator.isValidFirstname("SEGPRO"));
    }
    @Test
    public void FirstnameValidator_InvalidFirstnameNoUpperCase_ReturnsFalse() {
        assertFalse(FirstnameValidator.isValidFirstname("segpro"));
    }
    @Test
    public void FirstnameValidator_InvalidFirstnameHasdigitCase_ReturnsFalse() {
        assertFalse(FirstnameValidator.isValidFirstname("Seg9988"));
    }

}
